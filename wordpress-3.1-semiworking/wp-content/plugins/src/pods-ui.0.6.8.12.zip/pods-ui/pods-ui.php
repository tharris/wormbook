<?php
/*
Plugin Name: Pods UI
Plugin URI: http://ui.podscms.org/
Description: Allows you to develop plugins that look like WP using the Pods framework - requires Pods CMS plugin. Documentation for Pods UI can be found at http://ui.podscms.org/user-guide/ - Thanks for using Pods UI!
Version: 0.6.8.12
Author: Pods CMS
Author URI: http://podscms.org/

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

define("PODS_UI_URL",plugin_dir_url(__FILE__));

function pods_ui_manage($obj)
{
    pods_ui_validate_plugin();
    if(!is_array($obj)&&!is_object($obj)&&0<strlen($obj))
    {
        parse_str($obj,$obj);
    }
    if(is_array($obj)&&isset($obj['pod']))
    {
        $object = new Pod($obj['pod']);
        $object->ui = $obj;
    }
    else
    {
        $object = $obj;
    }
    if(!is_object($object))
    {
        echo '<strong>Error:</strong> Pods UI needs an object to run from, see the User Guide for more information.';
        return false;
    }
    if(!isset($object->ui)||!is_array($object->ui))
    {
        $object->ui = array();
    }
    $object->ui['title'] = (isset($object->ui['title'])?$object->ui['title']:ucwords(str_replace('_',' ',$object->datatype)));
    $object->ui['item'] = (isset($object->ui['item'])?$object->ui['item']:'Item');
    $object->ui['label'] = (isset($object->ui['label'])?$object->ui['label']:null);
    $object->ui['label_add'] = (isset($object->ui['label_add'])?$object->ui['label_add']:null);
    $object->ui['label_edit'] = (isset($object->ui['label_edit'])?$object->ui['label_edit']:null);
    $object->ui['label_duplicate'] = (isset($object->ui['label_duplicate'])?$object->ui['label_duplicate']:null);
    $object->ui['icon'] = (isset($object->ui['icon'])?$object->ui['icon']:null);
    $object->ui['columns'] = (isset($object->ui['columns'])?pods_ui_strtoarray($object->ui['columns']):array('name'=>'Name','created'=>'Date Created','modified'=>'Last Modified'));
    $object->ui['add_fields'] = (isset($object->ui['add_fields'])?pods_ui_strtoarray($object->ui['add_fields']):null);
    $object->ui['edit_fields'] = (isset($object->ui['edit_fields'])?pods_ui_strtoarray($object->ui['edit_fields']):null);
    $object->ui['duplicate_fields'] = (isset($object->ui['duplicate_fields'])?pods_ui_strtoarray($object->ui['duplicate_fields']):null);
    $object->ui['custom_list'] = (isset($object->ui['custom_list'])?$object->ui['custom_list']:null);
    $object->ui['custom_reorder'] = (isset($object->ui['custom_reorder'])?$object->ui['custom_reorder']:null);
    $object->ui['custom_edit'] = (isset($object->ui['custom_edit'])?$object->ui['custom_edit']:null);
    $object->ui['custom_add'] = (isset($object->ui['custom_add'])?$object->ui['custom_add']:$object->ui['custom_edit']);
    $object->ui['custom_duplicate'] = (isset($object->ui['custom_duplicate'])?$object->ui['custom_duplicate']:$object->ui['custom_edit']);
    $object->ui['custom_delete'] = (isset($object->ui['custom_delete'])?$object->ui['custom_delete']:null);
    $object->ui['custom_save'] = (isset($object->ui['custom_save'])?$object->ui['custom_save']:null);
    $object->ui['custom_actions'] = (isset($object->ui['custom_actions'])?pods_ui_strtoarray($object->ui['custom_actions']):array());
    $object->ui['manage_content'] = (isset($object->ui['manage_content'])?$object->ui['manage_content']:null);
    $object->ui['action_after_save'] = (isset($object->ui['action_after_save'])?$object->ui['action_after_save']:'edit');
    $object->ui['num'] = (isset($object->ui['num'])&&is_numeric($object->ui['num'])?$object->ui['num']:'');
    $object->ui['action'] = (isset($object->ui['action'])?$object->ui['action']:pods_ui_var('action'.$object->ui['num'],'get','manage'));
    $object->ui['edit_link'] = (isset($object->ui['edit_link'])&&!empty($object->ui['edit_link'])?$object->ui['edit_link']:null);
    $object->ui['view_link'] = (isset($object->ui['view_link'])&&!empty($object->ui['view_link'])?$object->ui['view_link']:null);
    $object->ui['duplicate_link'] = (isset($object->ui['duplicate_link'])&&!empty($object->ui['duplicate_link'])?$object->ui['duplicate_link']:null);
    $object->ui['reorder'] = (isset($object->ui['reorder'])?$object->ui['reorder']:null);
    $object->ui['reorder_columns'] = (isset($object->ui['reorder_columns'])?pods_ui_strtoarray($object->ui['reorder_columns']):$object->ui['columns']);
    $object->ui['reorder_sort'] = (isset($object->ui['reorder_sort'])?$object->ui['reorder_sort']:'t.'.$object->ui['reorder']);
    $object->ui['sort'] = (isset($object->ui['sort'])?$object->ui['sort']:'t.name');
    $object->ui['sortable'] = (isset($object->ui['sortable'])?false:null);
    if($object->ui['sortable']===null&&pods_ui_var('sort'.$object->ui['num'])!==false)
    {
        $dir = (pods_ui_var('sortdir'.$object->ui['num'])!==false?pods_ui_var('sortdir'.$object->ui['num']):'asc');
        $object->ui['sort'] = '`'.str_replace('.','`.`',pods_ui_var('sort'.$object->ui['num'])).'` '.$dir.','.$object->ui['sort'];
    }
    $object->ui['fields'] = ($object->ui['sortable']===null?pods_ui_fields($object->datatype_id):false);
    $object->ui['limit'] = (isset($object->ui['limit'])?(isset($_GET['limit'.$object->ui['num']])?$_GET['limit']:$object->ui['limit']):(isset($_GET['limit'.$object->ui['num']])?$_GET['limit'.$object->ui['num']]:25));
    $object->ui['where'] = (isset($object->ui['where'])?$object->ui['where']:'');
    $object->ui['edit_where'] = (isset($object->ui['edit_where'])?$object->ui['edit_where']:null);
    $object->ui['duplicate_where'] = (isset($object->ui['duplicate_where'])?$object->ui['duplicate_where']:$object->ui['edit_where']);
    $object->ui['delete_where'] = (isset($object->ui['delete_where'])?$object->ui['delete_where']:$object->ui['edit_where']);
    $object->ui['sql'] = (isset($object->ui['sql'])?$object->ui['sql']:null);
    $object->ui['search'] = (isset($object->ui['search'])&&is_bool($object->ui['search'])&&$object->ui['search']===false?false:null);
    $object->ui['filters'] = (isset($object->ui['filters'])&&!empty($object->ui['filters'])?pods_ui_strtoarray($object->ui['filters']):null);
    $object->ui['custom_filters'] = (isset($object->ui['custom_filters'])?$object->ui['custom_filters']:null);
    $object->ui['disable_actions'] = (isset($object->ui['disable_actions'])?pods_ui_strtoarray($object->ui['disable_actions']):array());
    if(in_array($object->ui['action'],$object->ui['disable_actions']))
    {
        $object->ui['action'] = 'manage';
    }
    $object->ui['hide_actions'] = (isset($object->ui['hide_actions'])?pods_ui_strtoarray($object->ui['hide_actions']):array());
    $object->ui['wpcss'] = (isset($object->ui['wpcss'])?true:null);
    if($object->ui['wpcss']!==null)
    {
        wp_print_styles(array('global','wp-admin'));
        global $user_ID;
        get_currentuserinfo();
        $color = get_usermeta($user_ID,'admin_color');
        if(strlen($color)<1)
        {
            $color = 'fresh';
        }
?>
<link rel='stylesheet' id='colors-css'  href='<?php bloginfo('wpurl'); echo '/wp-admin/css/colors-'.$color.'.css?ver='.date('Ymd'); ?>' type='text/css' media='all' />
<?php
    }
    if($object->ui['action']=='delete')
    {
        $access = $object->ui['delete_where'];
        $continue_delete = true;
        $delete = new Pod($object->datatype,pods_ui_var('id'.$object->ui['num']));
        if($delete->data!==false)
        {
            $check = pods_ui_verify_access($delete,$access,'delete');
            if($check===false)
            {
?>
<h2>Edit <?php echo $object->ui['item']; ?> <small>(<a href="<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'manage','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>">&laquo; Back to Manage</a>)</small></h2>
<?php
                pods_ui_message('<strong>Error:</strong> You do not have the permissions required to delete this '.$object->ui['item'].'.',2);
                $continue_delete = false;
            }
            if($continue_delete)
            {
                $delete->ui = $object->ui;
                if($object->ui['custom_delete']===null||!function_exists($object->ui['custom_delete']))
                {
                    pods_ui_delete($delete);
                }
                else
                {
                    $object->ui['custom_delete']($delete);
                }
            }
        }
        else
        {
            pods_ui_message($object->ui['item'].' <strong>not found</strong>, cannot delete.',2);
        }
    }
    if(!is_numeric($object->ui['num']))
    {
?>
<div class="wrap">
    <div id="icon-edit-pages" class="icon32"<?php if(null!==$object->ui['icon']){ ?> style="background-position:0 0;background-image:url(<?php echo $object->ui['icon']; ?>);"<?php } ?>><br /></div>
<?php
    }
    if($object->ui['action']=='add')
    {
        if($object->ui['custom_add']===null||!function_exists($object->ui['custom_add']))
        {
            pods_ui_form($object,1);
        }
        else
        {
            $object->ui['custom_add']($object);
        }
    }
    elseif($object->ui['action']=='edit')
    {
        $access = $object->ui['edit_where'];
        $continue_edit = true;
        $edit = new Pod($object->datatype,pods_ui_var('id'.$object->ui['num']));
        if($edit->data!==false)
        {
            $check = pods_ui_verify_access($edit,$access,'edit');
            if($check===false)
            {
?>
<h2>Edit <?php echo $object->ui['item']; ?> <small>(<a href="<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'manage','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>">&laquo; Back to Manage</a>)</small></h2>
<?php
                pods_ui_message('<strong>Error:</strong> You do not have the permissions required to edit this '.$object->ui['item'].'.',2);
                $continue_edit = false;
            }
            if($continue_edit)
            {
                $edit->ui = $object->ui;
                if($object->ui['custom_edit']===null||!function_exists($object->ui['custom_edit']))
                {
                    pods_ui_form($edit);
                }
                else
                {
                    $object->ui['custom_edit']($edit);
                }
            }
        }
        else
        {
            pods_ui_message($object->ui['item'].' <strong>not found</strong>, cannot edit.',2);
        }
    }
    elseif($object->ui['action']=='duplicate')
    {
        $access = $object->ui['duplicate_where'];
        $continue_duplicate = true;
        $duplicate = new Pod($object->datatype,pods_ui_var('id'.$object->ui['num']));
        if($duplicate->data!==false)
        {
            $check = pods_ui_verify_access($duplicate,$access,'duplicate');
            if($check===false)
            {
?>
<h2>Edit <?php echo $object->ui['item']; ?> <small>(<a href="<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'manage','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>">&laquo; Back to Manage</a>)</small></h2>
<?php
                pods_ui_message('<strong>Error:</strong> You do not have the permissions required to duplicate this '.$object->ui['item'].'.',2);
                $continue_duplicate = false;
            }
            if($continue_duplicate)
            {
                $duplicate->ui = $object->ui;
                if($object->ui['custom_duplicate']===null||!function_exists($object->ui['custom_duplicate']))
                {
                    pods_ui_form($duplicate,0,1);
                }
                else
                {
                    $object->ui['custom_duplicate']($duplicate);
                }
            }
        }
        else
        {
            pods_ui_message($object->ui['item'].' <strong>not found</strong>, cannot duplicate.',2);
        }
    }
    elseif($object->ui['reorder']!==null&&$object->ui['action']=='reorder')
    {
        $object->findRecords($object->ui['reorder_sort'],1000,$object->ui['where'],$object->ui['sql']);
        pods_ui_reorder($object);
    }
    else
    {
        if($object->ui['action']=='save')
        {
            if($object->ui['custom_save']!==null||function_exists($object->ui['custom_save']))
            {
                $object->ui['custom_save']($object);
            }
        }
        if(!empty($object->ui['custom_actions']))
        {
            $custom = new Pod($object->datatype,pods_ui_var('id'.$object->ui['num']));
            $custom->ui = $object->ui;
            if($custom->data!==false)
            {
                foreach($custom->ui['custom_actions'] as $action=>$function)
                {
                    if(pods_ui_var('action'.$custom->ui['num'])==$action&&function_exists($function))
                    {
                        $function($custom);
                        return;
                    }
                }
            }
        }
        if($object->ui['custom_list']!==null&&function_exists($object->ui['custom_list']))
        {
            $object->ui['custom_list']($object);
        }
        else
        {
            $oldget = $_GET;
            if(pods_ui_var('search'.$object->ui['num'])!==false)
            {
                if(false!==$object->ui['search'])
                {
                    $_GET['search'.$object->ui['num']] = pods_ui_var('search'.$object->ui['num']);
                }
                else
                {
                    $_GET['search'.$object->ui['num']] = '';
                }
            }
            if(pods_ui_var('pg'.$object->ui['num'])!==false)
            {
                $_GET['pg'] = pods_ui_var('pg'.$object->ui['num']);
            }
            else
            {
                $_GET['pg'] = '';
            }
            if(is_array($object->ui['filters']))
            {
                foreach($object->ui['filters'] as $filter)
                {
                    if(false!==pods_ui_var($filter.$object->ui['num']))
                    {
                        $_GET[$filter] = pods_ui_var($filter.$object->ui['num']);
                    }
                    else
                    {
                        $_GET[$filter] = '';
                    }
                }
            }
            $object->findRecords(pods_sanitize($object->ui['sort']),pods_sanitize($object->ui['limit']),$object->ui['where'],$object->ui['sql']);
            $_GET = $oldget;
        }
?>
    <h2>Manage <?php echo $object->ui['title']; ?></h2>
<?php
        if(false!==$object->ui['search']||is_array($object->ui['filters'])||null!=$object->ui['custom_filters'])
        {
?>
    <form id="posts-filter" action="" method="get">
        <p class="search-box">
<?php
            $hidden_fields = array('search'.$object->ui['num']);
            if(is_array($object->ui['filters']))
            {
                $hidden_filters = array();
                foreach ($object->ui['filters'] as $filter)
                {
                    $hidden_filters[] = $filter.$object->ui['num'];
                }
                $hidden_fields = array_merge($hidden_filters,$hidden_fields);
            }
            pods_ui_var_get($hidden_fields,'input');
?>
            <label class="screen-reader-text" for="page-search-input">Search:</label>
<?php
        if(false!==pods_ui_var('search'.$object->ui['num'])||(is_array($object->ui['filters'])&&false!==pods_ui_var($object->ui['filters'])))
            {
                $remove_filters = array('search'.$object->ui['num']);
                if(is_array($object->ui['filters']))
                        {
                               $remove_filters = array_merge($remove_filters,$object->ui['filters']);
                        }
               $reset_filters = array();
                foreach($remove_filters as $filter)
                    {
                        $reset_filters[$filter] = '';
                    }
?>
            <small>[<a href="<?php echo pods_ui_var_update($reset_filters); ?>">Reset Filters</a>]</small>
<?php
            }
            if ($object->ui['custom_filters']!==null)
            {
                echo $object->ui['custom_filters'];
            }
            if (is_array($object->ui['filters']))
            {
                foreach ($object->ui['filters'] as $key => $value)
                {
                    $field_name = trim($value);
                    $result = pod_query("SELECT pickval,label FROM @wp_pod_fields WHERE datatype = {$object->datatype_id} AND name = '$field_name' LIMIT 1");
                    if($row = @mysql_fetch_assoc($result))
                    {
                        if (!empty($row['pickval']))
                        {
                            $params = array(
                                'table' => $row['pickval'],
                                'field_name' => $field_name,
                                'tbl_row_ids' => false,
                                'unique_vals' => false,
                                'pick_filter' => '',
                                'pick_orderby' => ''
                            );
                            $data = $object->get_dropdown_values($params);
                            if(!empty($data))
                            {
?>
    <select name="<?php echo $field_name.$object->ui['num']; ?>" class="ui_filter <?php echo $field_name; ?>">
        <option value="">-- <?php echo (!empty($row['label'])?$row['label']:ucwords(str_replace('_', ' ', $field_name))); ?> --</option>
<?php
                                foreach ($data as $k => $v)
                                {
                                    $active = (false!==pods_ui_var($field_name.$object->ui['num'])&&$v['id']==pods_ui_var($field_name.$object->ui['num'])) ? ' selected' : '';
?>
        <option value="<?php echo $v['id']; ?>"<?php echo $active; ?>><?php echo $v['name']; ?></option>
<?php
                                }
?>
    </select>
<?php
                            }
                        }
                    }
                }
            }
            if(false!==$object->ui['search'])
            {
?>
            <input type="text" name="search<?php echo $object->ui['num']; ?>" id="page-search-input" value="<?php echo pods_ui_var('search'.$object->ui['num']); ?>" />
<?php
            }
?>
            <input type="submit" value="Search" class="button" />
        </p>
    </form>
<?php
        }
        if(0<$object->getTotalRows())
        {
?>
    <div class="tablenav">
        <div class="tablenav-pages">
            Show per page: <?php $ipp = 10; if($object->ui['limit']==$ipp){ ?><span class="page-numbers current"><?php echo $ipp; ?></span><?php } else { ?><a href="<?php echo pods_ui_var_update(array('limit'.$object->ui['num']=>$ipp,'pg'.$object->ui['num']=>'')); ?>"><?php echo $ipp; ?></a><?php } ?> <?php $ipp = 25; if($object->ui['limit']==$ipp){ ?><span class="page-numbers current"><?php echo $ipp; ?></span><?php } else { ?><a href="<?php echo pods_ui_var_update(array('limit'.$object->ui['num']=>$ipp,'pg'.$object->ui['num']=>'')); ?>"><?php echo $ipp; ?></a><?php } ?> <?php $ipp = 50; if($object->ui['limit']==$ipp){ ?><span class="page-numbers current"><?php echo $ipp; ?></span><?php } else { ?><a href="<?php echo pods_ui_var_update(array('limit'.$object->ui['num']=>$ipp,'pg'.$object->ui['num']=>'')); ?>"><?php echo $ipp; ?></a><?php } ?> <?php $ipp = 100; if($object->ui['limit']==$ipp){ ?><span class="page-numbers current"><?php echo $ipp; ?></span><?php } else { ?><a href="<?php echo pods_ui_var_update(array('limit'.$object->ui['num']=>$ipp,'pg'.$object->ui['num']=>'')); ?>"><?php echo $ipp; ?></a><?php } ?> <?php $ipp = 200; if($object->ui['limit']==$ipp){ ?><span class="page-numbers current"><?php echo $ipp; ?></span><?php } else { ?><a href="<?php echo pods_ui_var_update(array('limit'.$object->ui['num']=>$ipp,'pg'.$object->ui['num']=>'')); ?>"><?php echo $ipp; ?></a><?php } ?>&nbsp;&nbsp;|&nbsp;&nbsp;
<?php pods_ui_pagination($object); ?>
        </div>
<?php
            if(!in_array('add',$object->ui['disable_actions'])||(!in_array('reorder',$object->ui['disable_actions'])&&$object->ui['reorder']!==null))
            {
?>
        <div class="alignleft actions"><?php if(!in_array('add',$object->ui['disable_actions'])) { ?>
            <input type="button" value="Add New <?php echo $object->ui['item']; ?>" class="button" onclick="document.location='<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'add','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>'" /><?php } if($object->ui['reorder']!==null&&!in_array('reorder',$object->ui['disable_actions'])) { ?>
            <input type="button" value="Reorder" class="button" onclick="document.location='<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'reorder','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>'" /><?php } ?>
        </div>
<?php
            }
?>
        <br class="clear" />
    </div>
<?php
        pods_ui_table($object);
?>
    <div class="tablenav">
        <div class='tablenav-pages'>
<?php pods_ui_pagination($object); ?>
        </div>
        <br class="clear" />
    </div>
<?php
        }
        else
        {
            if(!in_array('add',$object->ui['disable_actions']))
            {
?>
    <div class="tablenav">
        <div class="alignleft actions">
            <input type="button" value="Add New <?php echo $object->ui['item']; ?>" class="button" onclick="document.location='<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'add','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>'" />
        </div>
        <br class="clear" />
    </div>
<?php
            }
            pods_ui_table(false);
        }
    }
    if(!is_numeric($object->ui['num']))
    {
?>
</div>
<?php
    }
}
function pods_ui_manage_content($filter=false)
{
    if(strpos(pods_ui_var('page'),'pods-manage-')!==false)
    {
        $datatype = pods_sanitize(str_replace('pods-manage-','',pods_ui_var('page')));
        $result = pod_query("SELECT is_toplevel,label FROM @wp_pod_types WHERE name = '$datatype' LIMIT 1");
        $row = mysql_fetch_assoc($result);
        if(1==$row['is_toplevel'])
        {
            if($filter)
            {
                return false;
            }
            pods_ui_manage('pod='.$datatype.'&title='.$row['label'].'&item='.$row['label'].'&sort=p.modified DESC');
        }
    }
    if(strpos(pods_ui_var('page'),'pod-')!==false)
    {
        $datatype = pods_sanitize(str_replace('pod-','',pods_ui_var('page')));
        $result = pod_query("SELECT is_toplevel,label FROM @wp_pod_types WHERE name = '$datatype' LIMIT 1");
        $row = mysql_fetch_assoc($result);
        if(1==$row['is_toplevel'])
        {
            if($filter)
            {
                return false;
            }
            pods_ui_manage('pod='.$datatype.'&title='.$row['label'].'&item='.$row['label'].'&action=add&manage_content=1&sort=p.modified DESC');
        }
    }
}
function pods_ui_table($object,$rows=null)
{
    if(!is_object($object)&&!is_array($rows))
    {
?>
<p>No items found</p>
<?php
        return false;
    }
    elseif(is_object($object))
    {
        $i=0;
        $view_link = $edit_link = $duplicate_link = $delete_link = array();
        while($object->fetchRecord())
        {
            $rows[$i] = array('id'=>$object->get_field('id'),'name'=>$object->get_field('name'));
            foreach($object->ui['columns'] as $key=>$column)
            {
                if(is_numeric($key))
                {
                    $key = $column;
                    $column = ucwords(str_replace('_',' ',$column));
                }
                $value = $object->get_field($key);
                if($key=='created'||$key=='modified')
                {
                    $value = '<abbr title="'.date('Y/m/d g:i:s A',strtotime($value)).'">'.date('Y/m/d g:i:s A',strtotime($value)).'</abbr>';
                }
                if(is_array($column)&&isset($column['display_helper']))
                {
                    $value = $object->pod_helper($column['display_helper'],$object->get_field($key),$key);
                }
                $rows[$i][$key] = $value;
            }
            $view_link[$i] = $object->get_field('detail_url');
            if($view_link[$i]==get_bloginfo('wpurl').'/')
            {
                $view_link[$i] = false;
            }
            if($object->ui['view_link']!==null)
            {
                $check = $object->pod_helper($object->ui['view_link'],$object->get_field('id'),$view_link[$i]);
                if(!empty($check))
                {
                    $view_link[$i] = $check;
                }
            }
            $check = pods_ui_verify_access($object,$object->ui['edit_where'],'edit');
            if($check===false)
            {
                $edit_link[$i] = false;
            }
            else
            {
                $edit_link[$i] = array('action'.$object->ui['num']=>'edit','id'.$object->ui['num']=>$object->get_field('id'),'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'');
                if($object->ui['edit_link']!==null)
                {
                    if(is_array($object->ui['edit_link']))
                    {
                        $edit_link[$i] = $object->ui['edit_link'];
                    }
                    else
                    {
                        $link = $object->pod_helper($object->ui['edit_link'],$object->get_field('id'),$edit_link[$i]);
                        $check = @json_decode($link,true);
                        if(is_array($check)&&!empty($check))
                        {
                            $edit_link[$i] = $check;
                        }
                        elseif(!empty($link))
                        {
                            $edit_link[$i] = $link;
                        }
                    }
                }
                if(is_array($edit_link[$i]))
                {
                    $edit_link[$i] = pods_ui_var_update($edit_link[$i]);
                }
            }
            $check = pods_ui_verify_access($object,$object->ui['duplicate_where'],'duplicate');
            if($check===false)
            {
                $duplicate_link[$i] = false;
            }
            else
            {
                $duplicate_link[$i] = array('action'.$object->ui['num']=>'duplicate','id'.$object->ui['num']=>$object->get_field('id'),'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'');
                if($object->ui['duplicate_link']!==null)
                {
                    if(is_array($object->ui['duplicate_link']))
                    {
                        $duplicate_link[$i] = $object->ui['duplicate_link'];
                    }
                    else
                    {
                        $link = $object->pod_helper($object->ui['duplicate_link'],$object->get_field('id'),$duplicate_link[$i]);
                        $check = @json_decode($link,true);
                        if(is_array($check)&&!empty($check))
                        {
                            $duplicate_link[$i] = $check;
                        }
                        elseif(!empty($link))
                        {
                            $duplicate_link[$i] = $link;
                        }
                    }
                }
                if(is_array($duplicate_link[$i]))
                {
                    $duplicate_link[$i] = pods_ui_var_update($duplicate_link[$i]);
                }
            }
            $check = pods_ui_verify_access($object,$object->ui['delete_where'],'delete');
            if($check===false)
            {
                $delete_link[$i] = false;
            }
            else
            {
                $delete_link[$i] = array('action'.$object->ui['num']=>'delete','id'.$object->ui['num']=>$object->get_field('id'),'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'');
                if($object->ui['duplicate_link']!==null)
                {
                    if(is_array($object->ui['delete_link']))
                    {
                        $delete_link[$i] = $object->ui['delete_link'];
                    }
                    else
                    {
                        $link = $object->pod_helper($object->ui['delete_link'],$object->get_field('id'),$delete_link[$i]);
                        $check = @json_decode($link,true);
                        if(is_array($check)&&!empty($check))
                        {
                            $delete_link[$i] = $check;
                        }
                        elseif(!empty($link))
                        {
                            $delete_link[$i] = $link;
                        }
                    }
                }
                if(is_array($delete_link[$i]))
                {
                    $delete_link[$i] = pods_ui_var_update($delete_link[$i]);
                }
            }
            $i++;
        }
    }
?>
<div class="clear"></div>
<?php
    if(is_array($rows))
    {
?>
<table class="widefat page fixed" cellspacing="0">
    <thead>
        <tr>
<?php
        $flag=false;
        foreach($object->ui['columns'] as $key=>$column)
        {
            $id = $class = '';
            if(is_numeric($key))
            {
                $key = $column;
                $column = ucwords(str_replace('_',' ',$column));
            }
            if($key=='name')
            {
                $id = 'title';
            }
            elseif($key=='created'||$key=='modified')
            {
                $id = 'date';
            }
            elseif(!$flag)
            {
                $id = 'author'; $flag=true;
            }
            if(0<strlen($id))
            {
                $class = ' column-'.$id; $id = ' id="'.$id.'"';
            }
            $label = $column;
            if(is_array($column)&&isset($column['label']))
            {
                $label = $column['label'];
            }
            $dir = (($object->ui['sortable']===null&&pods_ui_var('sort'.$object->ui['num'])==pods_ui_coltype($key,$object)&&pods_ui_var('sortdir'.$object->ui['num'])=='desc')?'asc':'desc');
            $sort = ($object->ui['sortable']===null?pods_ui_coltype($key,$object):null);
?>
            <th scope="col"<?php echo $id; ?> class="manage-column<?php echo $class; ?>"><?php if($object->ui['sortable']===null&&$sort!==null){ ?><a href="<?php echo pods_ui_var_update(array('sort'.$object->ui['num']=>$sort,'sortdir'.$object->ui['num']=>$dir)); ?>"><?php } echo $label; if($object->ui['sortable']===null){ ?></a><?php } ?></th>
<?php
        }
?>
        </tr>
    </thead>
    <tfoot>
        <tr>
<?php
        $flag=false;
        foreach($object->ui['columns'] as $key=>$column)
        {
            $id = $class = '';
            if(is_numeric($key))
            {
                $key = $column;
                $column = ucwords(str_replace('_',' ',$column));
            }
            if($key=='name')
            {
                $id = 'title';
            }
            elseif($key=='created')
            {
                $id = 'date';
            }
            elseif(!$flag)
            {
                $id = 'author'; $flag=true;
            }
            if(0<strlen($id))
            {
                $class = ' column-'.$id;
            }
            $label = $column;
            if(is_array($column)&&isset($column['label']))
            {
                $label = $column['label'];
            }
?>
            <th scope="col" class="manage-column<?php echo $class; ?>"><?php echo $label; ?></th>
<?php
        }
?>
        </tr>
    </tfoot>
    <tbody>
<?php
        foreach($rows as $i=>$row)
        {
?>
        <tr id="item-<?php echo $row['id']; ?>" class="iedit">
<?php
            foreach($object->ui['columns'] as $key=>$column)
            {
                $id = $class = '';
                if(is_numeric($key))
                {
                    $key = $column;
                    $column = ucwords(str_replace('_',' ',$column));
                }
                if($key=='name')
                {
                    $default_action = false;
                    $actions = array();
                    $defaults = array('edit','duplicate','delete','view');
                    foreach($defaults as $action)
                    {
                        $link_array = $action.'_link';
                        $link_array = $$link_array;
                        if(!in_array($action,$object->ui['disable_actions'])&&$link_array[$i]!==false)
                        {
                            if($default_action===false&&$action!='delete')
                                $default_action = array('name'=>ucwords($action),'link'=>$link_array[$i]);
                            if($action=='delete')
                                $actions[] = "<span class='delete'><a href='".$link_array[$i]."' title='".ucwords($action)." this item' class='submitdelete' onclick=\"if ( confirm('You are about to delete this item \'".htmlentities($row['name'])."\'\\n \'Cancel\' to stop, \'OK\' to delete.') ) { return true;}return false;\">".ucwords($action)."</a></span>";
                            else
                                $actions[] = "<span class='edit'><a href='".$link_array[$i]."' title='".ucwords($action)." this item'>".ucwords($action)."</a></span>";
                        }
                    }
                    if(!empty($object->ui['custom_actions']))
                    {
                        foreach($object->ui['custom_actions'] as $action=>$function)
                        {
                            if(function_exists($function)&&!in_array($action,$object->ui['disable_actions']))
                            {
                                if($default_action===false)
                                    $default_action = array('name'=>ucwords($action),'link'=>pods_ui_var_update(array('action'.$object->ui['num']=>$action,'id'.$object->ui['num']=>$row['id'],'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')));
                                $actions[] = "<span class='edit'><a href=\"".pods_ui_var_update(array('action'.$object->ui['num']=>$action,'id'.$object->ui['num']=>$row['id'],'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>''))."\" title=\"".ucwords($action)." this item\">".ucwords($action)."</a>";
                            }
                        }
                    }
?>
            <td class="post-title page-title column-title">
                <strong><?php if(is_array($default_action)){ ?><a class="row-title" href="<?php echo $default_action['link']; ?>" title="<?php echo $default_action['name']; ?> &#8220;<?php echo htmlentities($row['name']); ?>&#8221;"><?php echo $row['name']; ?></a><?php } else { echo $row['name']; } ?></strong>
<?php
                    if(!empty($actions))
                    {
?>
                <div class="row-actions"><?php echo implode(' | ',$actions); ?></div>
<?php
                    }
?>
            </td>
<?php
                    continue;
                }
                elseif($key=='created'||$key=='modified')
                {
                    $id = 'date';
                }
                elseif(!$flag)
                {
                    $id = 'author'; $flag=true;
                }
                if(0<strlen($id))
                {
                    $class = ' class="'.$id.' column-'.$id.'"';
                }
                $row_old = false;
                if(is_array($row[$key]))
                {
                    if(!empty($row[$key]))
                    {
                        $row_old = $row[$key];
                        $row[$key] = $row[$key][0][pods_ui_coltype($key,$object,true)];
                    }
                    else
                    {
                        $row[$key] = '';
                    }
                }
                if(is_array($column))
                {
                    if(isset($column['coltype'])&&$column['coltype']=='boolean')
                    {
                        if(is_numeric($row[$key])&&$row[$key]==1)
                        {
                            $row[$key] = 'Yes';
                        }
                        elseif(is_numeric($row[$key])&&$row[$key]==0)
                        {
                            $row[$key] = 'No';
                        }
                        elseif(0<strlen($row[$key])||!empty($row[$key]))
                        {
                            $row[$key] = 'Yes';
                        }
                        else
                        {
                            $row[$key] = 'No';
                        }
                    }
                }
?>
            <td<?php echo $class; ?>><?php echo $row[$key]; ?></td>
<?php
            }
?>
        </tr>
<?php
        }
?>
    </tbody>
</table>
<script type="text/javascript">
jQuery('table.widefat tbody tr:even').addClass('alternate');
</script>
<?php
    }
    else
    {
?>
<p>No items found</p>
<?php
    }
}
function pods_ui_pagination($object)
{
    $page = $object->page;
    $rows_per_page = $object->rpp;
    $total_rows = $object->getTotalRows();
    $total_pages = ceil($total_rows / $rows_per_page);
    $request_uri = pods_ui_var_update(array('pg'.$object->ui['num']=>'')).'&';
    $begin = ($rows_per_page*$page)-($rows_per_page-1);
    $end = ($total_pages==$page?$total_rows:($rows_per_page*$page));
?>
            <span class="displaying-num">Displaying <?php if($total_rows<1){ echo 0; } else { echo $begin; ?>&#8211;<?php echo $end; } ?> of <?php echo $total_rows; ?></span>
<?php
    if (1 < $page)
    {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo $page-1; ?>" class="prev page-numbers">&laquo;</a>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=1" class="page-numbers">1</a>
<?php
    }
    if (1 < ($page - 100))
    {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo ($page - 100); ?>" class="page-numbers"><?php echo ($page - 100); ?></a>
<?php
    }
    if (1 < ($page - 10))
    {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo ($page - 10); ?>" class="page-numbers"><?php echo ($page - 10); ?></a>
<?php
    }
    for ($i = 2; $i > 0; $i--)
    {
        if (1 < ($page - $i))
        {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo ($page - $i); ?>" class="page-numbers"><?php echo ($page - $i); ?></a>
<?php
       }
}
?>
            <span class="page-numbers current"><?php echo $page; ?></span>
<?php
    for ($i = 1; $i < 3; $i++)
    {
        if ($total_pages > ($page + $i))
        {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo ($page + $i); ?>" class="page-numbers"><?php echo ($page + $i); ?></a>
<?php
        }
    }
    if ($total_pages > ($page + 10))
    {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo ($page + 10); ?>" class="page-numbers"><?php echo ($page + 10); ?></a>
<?php
    }
    if ($total_pages > ($page + 100))
    {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo ($page + 100); ?>" class="page-numbers"><?php echo ($page + 100); ?></a>
<?php
    }
    if ($page < $total_pages)
    {
?>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo $total_pages; ?>" class="page-numbers"><?php echo $total_pages; ?></a>
            <a href="<?php echo $request_uri; ?>pg<?php echo $object->ui['num']; ?>=<?php echo $page+1; ?>" class="next page-numbers">&raquo;</a>
<?php
    }
}
function pods_ui_verify_access($object,$access,$what)
{
    if(is_array($access))
    {
        foreach($access as $field=>$match)
        {
            if($object->get_field($field)!=$match)
            {
                return false;
            }
        }
    }
    return true;
}
function pods_ui_form($object,$add=0,$duplicate=0)
{
    if(!is_object($object))
    {
        echo '<strong>Error:</strong> Pods UI needs an object to run from, see the User Guide for more information.';
        return false;
    }
    if($duplicate==1&&$object->id>0)
    {
        $add = 0;
        $fields = ($object->ui['duplicate_fields']!=null?$object->ui['duplicate_fields']:$object->ui['edit_fields']);
        $access = $object->ui['duplicate_where'];
        $what = 'Add New ';
        if($object->ui['label_duplicate']!==null)
        {
            $object->ui['label'] = $object->ui['label_duplicate'];
        }
        if($object->ui['label']===null)
        {
            $object->ui['label'] = 'Add New '.$object->ui['item'];
        }
    }
    elseif($add==0&&$object->id>0)
    {
        $fields = $object->ui['edit_fields'];
        $access = $object->ui['edit_where'];
        $what = 'Edit ';
        if($object->ui['label_edit']!==null)
        {
            $object->ui['label'] = $object->ui['label_edit'];
        }
        if($object->ui['label']===null)
        {
            $object->ui['label'] = 'Save Changes';
        }
    }
    else
    {
        $add = 1;
        $duplicate = 0;
        $fields = $object->ui['add_fields'];
        $access = null;
        $what = 'Add New ';
        if($object->ui['label_add']!==null)
        {
            $object->ui['label'] = $object->ui['label_add'];
        }
        if($object->ui['label']===null)
        {
            $object->ui['label'] = 'Add New '.$object->ui['item'];
        }
    }
?>
<h2><?php echo $what.$object->ui['item']; ?> <small>(<a href="<?php echo pods_ui_var_update(($object->ui['manage_content']!==null?array('page'=>'pods-manage-'.$object->datatype):array('action'.$object->ui['num']=>'manage','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>''))); ?>">&laquo; Back to Manage</a>)</small></h2>
<?php
    $check = pods_ui_verify_access($object,$access,strtolower($what));
    if($check===false)
    {
        pods_ui_message('<strong>Error:</strong> You do not have the permissions required to '.strtolower($what).' this '.$object->ui['item'].'.',2);
        return;
    }
    $viewit = '';
    if($add==0&&$object->get_field('detail_url')!=get_bloginfo('wpurl').'/')
    {
        $viewit = '&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.$object->get_field('detail_url').'">View '.$object->ui['item'].' &raquo;</a>';
    }
    if(isset($_GET['updated'.$object->ui['num']]))
    {
        pods_ui_message($object->ui['item'].' updated.'.$viewit);
    }
    elseif(isset($_GET['duplicated'.$object->ui['num']]))
    {
        pods_ui_message($object->ui['item'].' duplicated successfully.'.$viewit);
    }
    elseif(isset($_GET['added'.$object->ui['num']]))
    {
        $redirect_array = array('action'.$object->ui['num']=>'add','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'');
        $redirect_to = pods_ui_var_update($redirect_array,true);
        $redirect_array = array('action'.$object->ui['num']=>'duplicate','id'.$object->ui['num']=>$object->id,'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'');
        $redirect_to_duplicate = pods_ui_var_update($redirect_array,true);
        pods_ui_message($object->ui['item'].' added successfully. <a href="'.$redirect_to.'">Add another &raquo;</a>'.(!in_array('duplicate',$object->ui['disable_actions'])?'&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.$redirect_to_duplicate.'">Add another based on this one &raquo;</a>':'').$viewit);
    }
    elseif($duplicate==1)
    {
        pods_ui_message('<strong>About Duplicating:</strong> The form below is filled with information based off an existing '.$object->ui['item'].'. By saving this information, you will create a new '.$object->ui['item'].' and nothing will be overwritten.');
    }
    ob_start();
    $object->publicForm($fields,$object->ui['label']);
    $form = ob_get_clean();
    $actionwhat = 'updated';
    if($duplicate==1)
        $actionwhat = 'duplicated';
    elseif($add==1)
        $actionwhat = 'added';
    $redirect_array = array('action'.$object->ui['num']=>'edit','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'',$actionwhat.$object->ui['num']=>1);
    $redirect_to = pods_ui_var_update($redirect_array,true).'&id="+msg+"';
    if($object->ui['action_after_save']!=null)
    {
        $redirect_array = array('action'.$object->ui['num']=>$object->ui['action_after_save'],'id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'',$actionwhat.$object->ui['num']=>1);
        $redirect_to = pods_ui_var_update($redirect_array,true).($object->ui['action_after_save']=='edit'?'&id="+msg+"':'');
    }
    $form = str_replace('window.location = "'.$_SERVER['REQUEST_URI'].'";','window.location = "'.$redirect_to.'";',$form);
    if(!in_array('delete',$object->ui['disable_actions'])&&$object->id!=null&&$duplicate==0)
        $form = str_replace('<input type="button" class="button btn_save" value="'.$object->ui['label'].'" onclick="saveForm(1)" />','<input type="button" class="button btn_save" value="'.$object->ui['label'].'" onclick="saveForm(1)" />&nbsp;&nbsp;&nbsp;<a style="color:#red;font-weight:normal;text-decoration:underline;font-style:italic;" title="Delete this item" href="'.pods_ui_var_update(array('action'.$object->ui['num']=>'delete','id'.$object->ui['num']=>$object->get_field('id'),'updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')).'" onclick="if ( confirm(\'You are about to delete this item \\\''.htmlentities($object->get_field('name')).'\\\'\n \\\'Cancel\\\' to stop, \\\'OK\\\' to delete.\') ) { return true;}return false;">Delete this item</a>',$form);
    if($duplicate==1)
        $form = str_replace('<input type="hidden" class="form num pod_id" value="'.$object->get_pod_id().'" />','<input type="hidden" class="form num pod_id" value="0" />',$form);
    echo $form;
}
function pods_ui_reorder($object)
{
    global $_registered_pages;
    if(!isset($_registered_pages['toplevel_page_pods']))
    {
        wp_print_scripts(array('jquery-ui-core','jquery-ui-sortable'));
    }
?>
<script type="text/javascript">
function pods_ui_reorder() {
    var order = "";
    jQuery("table#pods_ui_reorder tbody tr").each(function() {
        order += jQuery(this).attr("id").substr(5) + ",";
    });
    order = order.slice(0, -1);

    jQuery.ajax({
        type: "post",
        url: "<?php echo PODS_UI_URL; ?>api.php",
        data: "action=save_reorder&dt=<?php echo $object->datatype; ?>&field=<?php echo $object->ui['reorder']; ?>&order="+order,
        success: function(msg) {
            if ("Error" == msg.substr(0, 5)) {
                alert(msg);
            }
            else {
                alert("Success!");
            }
        }
    });
}
</script>
<style type="text/css">
.dragme {
    background: url(<?php echo PODS_URL; ?>/ui/images/move.png) no-repeat;
    background-position:8px 5px;
    cursor:pointer;
}
</style>
<h2>Reorder <?php echo $object->ui['item']; ?> <small>(<a href="<?php echo pods_ui_var_update(array('action'.$object->ui['num']=>'manage','id'.$object->ui['num']=>'','updated'.$object->ui['num']=>'','duplicated'.$object->ui['num']=>'','added'.$object->ui['num']=>'','search'.$object->ui['num']=>'')); ?>">&laquo; Back to Manage</a>)</small></h2>
<?php
    if(!is_object($object))
    {
?>
<p>No items found</p>
<?php
        return false;
    }
    elseif(is_object($object))
    {
        $rows = array();
        $i=0;
        while($object->fetchRecord())
        {
            $rows[$i] = array('id'=>$object->get_field('id'),'name'=>$object->get_field('name'));
            foreach($object->ui['reorder_columns'] as $key=>$column)
            {
                if(is_numeric($key))
                {
                    $key = $column;
                    $column = ucwords(str_replace('_',' ',$column));
                }
                if($key=='id'||$key=='name')
                {
                    continue;
                }
                elseif($key=='created')
                {
                    $value = strtotime($object->get_field($key));
                }
                elseif($key=='modified')
                {
                    $value = strtotime($object->get_field($key));
                }
                else
                {
                    $value = $object->get_field($key);
                }
                $rows[$i][$key] = $value;
            }
            $i++;
        }
    }
?>
<div class="tablenav">
    <div class="alignleft actions">
        <input type="button" value="Update Order" class="button" onclick="pods_ui_reorder();" />
    </div>
    <div class="clear"></div>
</div>
<div class="clear"></div>
<?php
    if(is_array($rows))
    {
?>
<table class="widefat page fixed" id="pods_ui_reorder" cellspacing="0">
    <thead>
        <tr>
<?php
        $flag=false;
        foreach($object->ui['reorder_columns'] as $key=>$column)
        {
            $id = $class = '';
            if(is_numeric($key))
            {
                $key = $column;
                $column = ucwords(str_replace('_',' ',$column));
            }
            if($key=='name')
            {
                $id = 'title';
            }
            elseif($key=='created'||$key=='modified')
            {
                $id = 'date';
            }
            elseif(!$flag)
            {
                $id = 'author'; $flag=true;
            }
            if(0<strlen($id))
            {
                $class = ' column-'.$id; $id = ' id="'.$id.'"';
            }
            $label = $column;
            if(is_array($column)&&isset($column['label']))
            {
                $label = $column['label'];
            }
?>
            <th scope="col"<?php echo $id; ?> class="manage-column<?php echo $class; ?>"><?php echo $label; ?></th>
<?php
        }
?>
        </tr>
    </thead>
    <tfoot>
        <tr>
<?php
        $flag=false;
        foreach($object->ui['reorder_columns'] as $key=>$column)
        {
            $id = $class = '';
            if(is_numeric($key))
            {
                $key = $column;
                $column = ucwords(str_replace('_',' ',$column));
            }
            if($key=='name')
            {
                $id = 'title';
            }
            elseif($key=='created')
            {
                $id = 'date';
            }
            elseif(!$flag)
            {
                $id = 'author'; $flag=true;
            }
            if(0<strlen($id))
            {
                $class = ' column-'.$id;
            }
            $label = $column;
            if(is_array($column)&&isset($column['label']))
            {
                $label = $column['label'];
            }
?>
            <th scope="col" class="manage-column<?php echo $class; ?>"><?php echo $label; ?></th>
<?php
        }
?>
        </tr>
    </tfoot>
    <tbody class="sortable">
<?php
        foreach($rows as $key=>$row)
        {
?>
        <tr id="item-<?php echo $row['id']; ?>" class="iedit">
<?php
            foreach($object->ui['reorder_columns'] as $key=>$column)
            {
                $id = $class = '';
                if(is_numeric($key))
                {
                    $key = $column;
                    $column = ucwords(str_replace('_',' ',$column));
                }
                if($key=='name')
                {
                    if(is_array($column)&&isset($column['display_helper']))
                        {
                            $object->data = $row;
                            $row['name'] = $object->pod_helper($column['display_helper'],$row['name'],'name');
                        }
?>
            <td class="post-title page-title column-title dragme"><strong style="margin-left:30px;"><?php echo $row['name']; ?></strong></td>
<?php
                    continue;
                }
                elseif($key=='created'||$key=='modified')
                {
                    if(is_array($column)&&isset($column['display_helper']))
                        {
                            $id = 'date';
                            $object->data = $row;
                            $row[$key] = $object->pod_helper($column['display_helper'],$row[$key],$key);
                        }
                    else
                        {
                            $id = 'date'; $row[$key] = '<abbr title="'.date('Y/m/d g:i:s A',$row[$key]).'">'.date('Y/m/d g:i:s A',$row[$key]).'</abbr>';
                        }
                }
                elseif(!$flag)
                {
                    $id = 'author'; $flag=true;
                }
                if(0<strlen($id))
                {
                    $class = ' class="'.$id.' column-'.$id.'"';
                }
                $row_old = false;
                if(is_array($row[$key]))
                {
                    if(!empty($row[$key]))
                    {
                        $row_old = $row[$key];
                        $row[$key] = $row[$key][0][pods_ui_coltype($key,$object,true)];
                    }
                    else
                    {
                        $row[$key] = '';
                    }
                }
                if(is_array($column))
                {
                    if(isset($column['display_helper']))
                        {
                            if($row_old!==false){$row[$key] = $row_old;}
                            $object->data = $row;
                            $row[$key] = $object->pod_helper($column['display_helper'],$row[$key],$key);
                        }
                    elseif(isset($column['coltype'])&&$column['coltype']=='boolean')
                        {
                            if(is_numeric($row[$key])&&$row[$key]==1)
                            {
                                $row[$key] = 'Yes';
                            }
                            elseif(is_numeric($row[$key])&&$row[$key]==0)
                            {
                                $row[$key] = 'No';
                            }
                            elseif(0<strlen($row[$key])||!empty($row[$key]))
                            {
                                $row[$key] = 'Yes';
                            }
                            else
                            {
                                $row[$key] = 'No';
                            }
                        }
                }
?>
            <td<?php echo $class; ?>><?php echo $row[$key]; ?></td>
<?php
            }
?>
        </tr>
<?php
        }
?>
    </tbody>
</table>
<div class="tablenav">
    <div class="alignleft actions">
        <input type="button" value="Update Order" class="button" onclick="pods_ui_reorder();" />
    </div>
    <div class="clear"></div>
</div>
<div class="clear"></div>
<script type="text/javascript">
jQuery('table.widefat tbody tr:even').addClass('alternate');
jQuery(document).ready(function(){
    jQuery(".sortable").sortable({axis: "y", handle: ".dragme"});
    jQuery(".sortable").bind('sortupdate', function(event, ui){
        jQuery('table.widefat tbody tr').removeClass('alternate');
        jQuery('table.widefat tbody tr:even').addClass('alternate');
    });
});
</script>
<?php
    }
    else
    {
?>
<p>No items found</p>
<?php
    }
}
function pods_ui_delete($object,$msg=true)
{
    $pod_id = $object;
    $item = 'Item';
    if(is_object($object))
    {
        $pod_id = $object->get_pod_id();
        $item = $object->ui['item'];
    }
    if(!is_bool($msg))
    {
        $item = $msg;
    }
    $api = new PodAPI();
    $api->drop_pod_item(array('pod_id'=>$pod_id));
    if($msg!==false)
    {
        pods_ui_message($item.' <strong>deleted</strong>.');
    }
}
function pods_ui_validate_package($package) // DEPRECATED
{
    $api = new PodAPI();
    return $api->validate_package($package);
}
function pods_ui_import_package($package) // DEPRECATED
{
    $api = new PodAPI();
    $validate = $api->validate_package($package);
    if(!is_bool($validate))
    {
        pods_ui_message('Package failed validation: '.$validate,2);
        return false;
    }
    return $api->import_package($package);
}
function pods_ui_message($msg,$error=false)
{
?>
    <div id="message" class="<?php echo ($error?'error':'updated'); ?> fade"><p><?php echo $msg; ?></p></div>
<?php
}
function pods_ui_var($var,$method='get',$default=null)
{
    if(is_array($var))
    {
        foreach($var as $key)
        {
            if(false!==pods_ui_var($key,$method,$default))
            {
                return true;
            }
        }
        return false;
    }
    $ret = false;
    if(!is_array($method)&&$method=='get'&&isset($_GET[$var]))
    {
        $ret = $_GET[$var];
    }
    elseif(!is_array($method)&&$method=='post'&&isset($_POST[$var]))
    {
        $ret = $_POST[$var];
    }
    elseif(is_array($method)&&isset($method[$var]))
    {
        $ret = $method[$var];
    }
    if($ret===false&&$default!==null)
    {
        $ret = $default;
    }
    return pods_sanitize($ret);
}
function pods_ui_var_update($arr=false,$url=false)
{
    if(!isset($_GET))
    {
        $get = array();
    }
    else
    {
        $get = $_GET;
    }
    if(is_array($arr))
    {
        foreach($arr as $key=>$val)
        {
            if(0<strlen($val))
            {
                $get[$key] = $val;
            }
            else
            {
                unset($get[$key]);
            }
        }
    }
    if($url===false)
    {
        $url = '';
    }
    else
    {
        $url = explode('?',$_SERVER['REQUEST_URI']);
        $url = explode('#',$url[0]);
        $url = $url[0];
    }
    return $url.'?'.http_build_query($get);
}
function pods_ui_var_get($arr=false,$format=false)
{
    if(!isset($_GET))
    {
        $get = array();
    }
    else
    {
        $get = $_GET;
    }
    if(is_array($arr))
    {
        foreach($arr as $key=>$val)
        {
            if(0<strlen($val))
            {
                $get[$key] = $val;
            }
            else
            {
                unset($get[$key]);
            }
        }
    }
    if($format!==false&&$format=='input')
    {
        foreach($get as $k=>$v)
        {
?>
<input type="hidden" name="<?php echo $k; ?>" value="<?php echo $v; ?>" />
<?php
        }
    }
}
function pods_ui_strtoarray($var)
{
    if(is_array($var))
    {
        return $var;
    }
    else
    {
        return explode(',',$var);
    }
}
function pods_ui_fields($datatype_id)
{
    $fields = array();
    $result = pod_query("SELECT * FROM @wp_pod_fields WHERE datatype = $datatype_id ORDER BY weight", 'Cannot get datatype fields');
    while($row = mysql_fetch_assoc($result))
    {
        $fields[$row['name']] = $row;
    }
    return $fields;
}
function pods_ui_coltype($column,$object,$t=false)
{
    $column = explode('.',$column);
    if(isset($column[1]))
    {
        $t = true;
    }
    $column = $column[0];
    $fields = $object->ui['fields'];
    if($fields===false)
    {
        $fields = pods_ui_fields($object->datatype_id);
    }
    if(empty($fields))
    {
        return ($t?'':'t.').$column;
    }
    elseif(isset($fields[$column]))
    {
        if($fields[$column]['coltype']=='pick')
        {
            if(strpos($fields[$column]['pickval'],'wp_')!==false)
            {
                if($fields[$column]['pickval']=='wp_user')
                {
                    return ($t?'':$column.'.').'display_name';
                }
                else
                {
                    return ($t?'':$column.'.').($t?'post_title':'post_name');
                }
            }
            else
            {
                return ($t?'':$column.'.').'name';
            }
        }
        elseif($fields[$column]['coltype']=='file')
        {
            return ($t?'':$column.'.').($t?'guid':'post_name');
        }
        else
        {
            return ($t?'':'t.').$column;
        }
    }
    elseif($column=='created'||$column=='modified')
    {
        return ($t?'':'p.').$column;
    }
}
function pods_ui_validate_plugin()
{
        $missing = false;
        if(!function_exists("pod_query"))
        {
            $missing = 'Pods';
        }
        if(!is_bool($missing))
        {
            die('<strong>Fatal Error:</strong> Missing required plugin: '.$missing);
        }
}

add_action('pods_manage_content','pods_ui_manage_content');
add_filter('pods_manage_content','pods_ui_manage_content');