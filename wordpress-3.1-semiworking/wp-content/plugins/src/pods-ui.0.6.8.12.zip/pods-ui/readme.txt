=== Pods UI ===
Contributors: sc0ttkclark
Donate link: http://ui.podscms.org/
Tags: cms, pods, cck, drupal, joomla, content types, pages, datatypes
Requires at least: 2.7
Tested up to: 3.0.1
Stable tag: 0.6.8.12

Allows you to develop plugins that look like WP using the Pods CMS Framework (installed separately). Pods CMS Framework is a plugin for WordPress.

== Description ==

Pods UI allows you to develop plugins that look like WP using the Pods CMS Framework (installed separately). This plugin does not include Pods, it must be downloaded / installed separately. It is not meant to replace Pods, only to enhance how you use Pods and manage it's information.

Documentation is available in the [User Guide](http://ui.podscms.org/user-guide/) on our site.

See demo.php contained in this plugin for demonstration code showing you just a few examples of the possibilities.

FOR SUPPORT RELATED TO THIS PLUGIN: Please go to our [site](http://ui.podscms.org/).

Pods CMS Framework is a plugin for WordPress that lets you create, manage, and display your own content types. Visit the [Pods homepage](http://podscms.org/) or [Download Pods on the WP.org Repository](http://wordpress.org/extend/plugins/pods/)

== Installation ==

1. Unpack the entire contents of this plugin zip file into your `wp-content/plugins/` folder locally
1. Upload to your site
1. Navigate to `wp-admin/plugins.php` on your site (your WP plugin page)
1. Activate this plugin

OR you can just install it with WordPress by going to Plugins >> Add New >> and type this plugin's name