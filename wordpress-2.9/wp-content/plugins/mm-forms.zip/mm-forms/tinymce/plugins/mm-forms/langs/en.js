tinyMCE.addI18n('en.mm_forms',{
	desc : 'Insert mm forms tag to your page/post'
});
