tinyMCE.addI18n('en.mm_forms_dlg',{
	title : 'Insert mm form tag'
});
