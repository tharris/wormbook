=== Flutter ===
Contributors: freshout
Tags: custom write panel, custom, write panel, cms, freshout
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=navid%40freshout%2eus&lc=US&item_name=Flutter&item_number=Flutter_Donation&cn=Add%20special%20instructions%20to%20the%20seller&no_shipping=2&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Requires at least: 2.7
Tested up to: 2.8
Stable tag: 1.1

Flutter is a feature rich WordPress CMS plugin by Freshout. 

== Description ==

Flutter is a feature rich WordPress CMS plugin that focuses on easy templating for the developer and simplifies content management for the admin by creating custom write panels that can be fully customized (radio buttons, file uploads, image uploads, checkboxes, etc). 

Flutter also includes power image manipulation (automatic resizing, cropping, watermarking, etc), edit in place (works instantly!), and modulation of your themes. 

If you enjoy using Flutter, please donate or contribute in some way.

== Screenshots ==

[Flutter Home](http://flutter.freshout.us/)

== Installation ==

Follow the following steps to install this plugin.

1. Download plugin to the `/wp-content/plugins/` folder.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Upgrade ==

After version .30 the files flutter folder should be in the wp-content folder, if you be upgrading from an older version to .30 put your files in this place. 

== Frequently Asked Questions ==

[Flutter Home](http://flutter.freshout.us/)
